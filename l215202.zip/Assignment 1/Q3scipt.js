const submittedApplications = [];

function submitForm() {
    if (validateForm()) {
        const formData = collectFormData();
        submittedApplications.push(formData);
        console.log("Form submitted successfully!");
        console.log(formData);
        document.getElementById("jobApplicationForm").reset();
    }
}

function validateForm() {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^\d{11}$/;

    const emailInput = document.getElementById("email");
    if (!emailRegex.test(emailInput.value)) {
        alert("Please enter a valid email address.");
        emailInput.focus();
        return false;
    }

    const phoneInput = document.getElementById("phoneNumber");
    if (!phoneRegex.test(phoneInput.value)) {
        alert("Please enter a valid 10-digit phone number.");
        phoneInput.focus();
        return false;
    }

    return true;
}

function collectFormData() {
    const formData = {
        firstName: document.getElementById("firstName").value,
        lastName: document.getElementById("lastName").value,
        phoneNumber: document.getElementById("phoneNumber").value,
        email: document.getElementById("email").value,
        street: document.getElementById("street").value,
        city: document.getElementById("city").value,
        state: document.getElementById("state").value,
        zipCode: document.getElementById("zipCode").value,
        
        educationLevel: document.getElementById("educationLevel").value,
        school: document.getElementById("school").value,
        major: document.getElementById("major").value,
        graduationYear: document.getElementById("graduationYear").value,

        jobTitles: document.getElementById("jobTitles").value,
        companyNames: document.getElementById("companyNames").value,
        employmentDates: document.getElementById("employmentDates").value,
        jobResponsibilities: document.getElementById("jobResponsibilities").value,

        relevantSkills: document.getElementById("relevantSkills").value,
        certifications: document.getElementById("certifications").value,

        startDate: document.getElementById("startDate").value,
        workSchedule: document.getElementById("workSchedule").value,
        relocate: document.getElementById("relocate").value,

        referenceName: document.getElementById("referenceName").value,
        referenceContact: document.getElementById("referenceContact").value,
        relationship: document.getElementById("relationship").value,

        reasonToWork: document.getElementById("reasonToWork").value,
    };

    return formData;
}


function viewApplicationsAsTable() {
    const tableContainer = document.getElementById("tableContainer");
    tableContainer.innerHTML = "";

    if (submittedApplications.length === 0) {
        tableContainer.innerHTML = "<p>No applications submitted yet.</p>";
    } else {
        const table = document.createElement("table");
        const headerRow = table.insertRow(0);

        for (const key in submittedApplications[0]) {
            if (submittedApplications[0].hasOwnProperty(key)) {
                const th = document.createElement("th");
                th.textContent = key;
                headerRow.appendChild(th);
            }
        }

        submittedApplications.forEach((application, index) => {
            const row = table.insertRow(index + 1);
            for (const key in application) {
                if (application.hasOwnProperty(key)) {
                    const cell = row.insertCell();
                    cell.textContent = application[key];
                }
            }
        });

        tableContainer.appendChild(table);
    }
}
